# Frontend (React)

## Quickstart

1. Install dependencies:

```bash
cd frontend
npm install
```

2. Start the dev server:

```bash
npm start
```

The dev server proxies API requests to `http://localhost:8000` as configured in `package.json`.