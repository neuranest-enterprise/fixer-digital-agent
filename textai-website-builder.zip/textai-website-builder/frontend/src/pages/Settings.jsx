import React from 'react';

function Settings() {
  return (
    <div style={{ padding: 24 }}>
      <h2>Settings</h2>
      <p>Configure provider preferences and API keys (stored locally for dev).</p>
    </div>
  );
}

export default Settings;