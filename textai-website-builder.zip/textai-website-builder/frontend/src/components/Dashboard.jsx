import React from 'react';

function Dashboard() {
  return (
    <section>
      <h3>Dashboard</h3>
      <div>Metrics and charts placeholder</div>
    </section>
  );
}

export default Dashboard;