import React from 'react';

function Editor() {
  return (
    <section>
      <h3>Editor</h3>
      <div>Drag-and-drop canvas placeholder</div>
    </section>
  );
}

export default Editor;