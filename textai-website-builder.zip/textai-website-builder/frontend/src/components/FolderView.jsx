import React from 'react';

function FolderView() {
  return (
    <section>
      <h3>Projects / Folders</h3>
      <div>List and manage project folders</div>
    </section>
  );
}

export default FolderView;